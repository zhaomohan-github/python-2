# 选择
"""
1D
2D
3B
4A
5B
6D
7A
8D
9A
10B
11D
12A
13A
14D
15A
16C
17B
18B
19C
20D
"""
# 操作1
def fib(n):
    a = 0
    b = 1
    if n == 0: 
        return a
    elif n == 1:
        return b
        
    for i in range(n - 1):
        a, b = b, a + b
        # print(a, b)
    
    return b
    
    
n = int(input())
print(fib(n)
        
# 操作2
print(max(map(int, input().split('.'))))

# 操作3
import turtle as t

# t.tracer(0)

y1 = 100
y2 = -100

# 绘制扇柄
t.pencolor("lightgreen")
t.penup()
t.goto(0, y2)
t.left(90)
t.pensize(50)
t.pendown()
t.fd(100)

# 绘制底盘
t.penup()
t.goto(0, y1)
t.dot(200)
t.pencolor("tan")
t.dot(180)

# 绘制扇叶
t.pencolor("lightgreen")
t.pensize(3)
for i in range(20):
    t.pendown()
    t.fd(90)
    t.left(360//20)
    t.penup()
    t.goto(0, y1)

# 绘制中心
t.dot(50)

t.ht()
# t.update()
