"""
1d
2d
3b
4a
5c
6d
7c
8a
9b
10b
11d
12b
13c
14a
15d
16a
17d
18b
19b
20a
"""
# 操作1
lst = []
for i in range(4):
    lst.append(int(input('请输入数字：')))
lst.sort()
for i in lst:
    print(i)
    
# 操作2 
class Phone:
    def __init__(self, product, ram, price):
        self.product = product
        self.ram = ram
        self.price = price
    
class Iphone(Phone):
    def __init_(self, size):
        super().__init__(product, ram, price, size)
        self.size = size
    
    def show(self):
        print('型号：% s，内存大小：% s，屏幕大小：% s' % (self.product, self.ram, self.size))
        print('该型号手机售价是：% s' % self.price)

m = input('请输入型号：')
r = input('请输入内存大小：')
p = input('请输入售价：')
s = input('请输入屏幕大小：')

iphone = Iphone(m, r, p, s)
iphone.show()

# 操作3
# 数学方式 坐标 

import turtle as t

t.pensize(10)
t.pencolor("SaddleBrown")
w, h = 300, 260
t.speed(0)
# 绘制脸部
for i in range(2):
    t.fd(w)
    t.left(90)
    t.fd(h)
    t.left(90)

# 耳朵
# 左耳朵坐标 (0, h)
t.goto(0, h)
t.setheading(90)
t.circle(-50, 180)

# 右耳
t.goto(w, h)
t.setheading(90)
t.circle(50, 180)

# 左眼睛 (w // 4, h // 3)
t.penup()
t.goto(w // 4, h  *  3 / 4)
t.dot(30)

# 右眼睛
t.penup()
t.goto(w * 3/4, h * 3/4)
t.dot(30)

# 鼻子
# 移到四分之三坐标 (w // 2, h // 3)
t.penup()
t.goto(w // 2, h // 3)
t.pendown()
# 上半部分
t.setheading(0)
t.fillcolor('SaddleBrown')
t.begin_fill()
t.left(30)
t.fd(100)
t.left(150)
t.fd(170)
t.left(150)
t.fd(100)
t.end_fill()
# 下半部分
t.setheading(-90)
t.fd(h//3)


t.done()

