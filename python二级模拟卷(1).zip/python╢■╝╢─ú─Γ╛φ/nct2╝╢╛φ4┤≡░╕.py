# 选择题
"""
1b
2d
3b
4a
5c
6b
7b
8d
9a
10c
11c
12b
13d
14a
15d
16c
17d
18a
19d
20b
"""

# 操作题1

import random

a = int(input())
b = int(input())

n = random.randint(a, b)
print(int(n ** 0.5))


# 方法二 内置模块
import random
import math

a = int(input())
b = int(input())

n = random.randint(a, b)
print(int(math.floor(math.sqrt(n))))


# 操作题2
def f(lst):
    lst.sort()
    diff = lst[1] - lst[0]
    for i in range(len(lst) - 1):
        if lst[i+1] - lst[i] != diff:
            return False
    return True

lst = list(map(int, input().split()))
if f(lst):
    print(lst)
else:
    print(0)


# 操作题3
import turtle as t

def rectangle():
     for i in range(2):
          t.fd(100)
          t.left(90)
          t.fd(30)
          t.left(90)

          
colors = ["pink", "blue", "red", "green"]
for color in colors:
     t.pencolor(color)
     rectangle()
     t.left(90)
     
     

