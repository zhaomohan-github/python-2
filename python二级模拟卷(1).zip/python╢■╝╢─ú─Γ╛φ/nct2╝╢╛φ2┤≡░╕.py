"""
1a
2c
3d
4c
5c
6d
7c
8b
9b
10b
11d
12c
13b
14d
15b
16b
17c
18d
19d
10b
"""

# 操作1
import math
def quadratic(a, b, c):
    key = b**2-4*a*c
    if key > 0:
        x1 = round((-b+math.sqrt(key))/2*a, 1)
        x2 = (-b-math.sqrt(key))/2*a
    if key == 0:
        x1 = round(-b/2*a, 2)
        x2 = x1
    if key < 0:
        print('方程无解')
        return(None)
    return (round(x1, 1), round(x2, 1))
x = int(input())
y = int(input())
z = int(input())
print(quadratic(x, y, z))


# 操作2
def fac(n):  # 计算阶乘
    if n < 2:
        return 1
    else:
        return n*fac(n-1)


num = int(input())
sum_fac = 0  # 存储计算的结果
for i in range(num+1):  # 循环遍历要求阶乘的所有数字，进行累加
    sum_fac += fac(i)
print(sum_fac)

# 操作3
import turtle as t
def draw_tree(branch_length):
    if branch_length > 0:
        t.forward(branch_length)  # 画树干
        t.right(20)  # 画笔右转，准备画右边的小树
        draw_tree(branch_length-20)  # 递归调用，画右边小树，树干减20
        t.left(40)  #画笔左转，准备画左边的小树
        draw_tree(branch_length-20)  # 递归调用，画左边小树，树干减20
        t.right(20)  # 所有分叉画完后，画笔回到初始角度
        t.backward(branch_length)  # 将画笔退回到原位置


t.left(90)  # 因为画笔默认方向是向右的，所以需要调整初始角度向上
t.up() 
t.backward(200)
t.down()  
t.color('green')
draw_tree(100)
t.done()