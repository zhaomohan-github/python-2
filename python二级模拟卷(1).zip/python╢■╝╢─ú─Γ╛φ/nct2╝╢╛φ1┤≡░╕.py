"""
1D
2B
3A
4D
5D
6C
7C
8C
9D
10A
11B
12A
13B
14D
15D
16A
17A
18D
19B
20B
"""

# 操作题1
lst = list(map(int, input().split(',')))
n = int(input())
cnt = 0
for i in range(len(lst)):
     for j in range(i+1, len(lst)):
          if lst[i] + lst[j] == n:
               cnt += 1
print(cnt)

# 操作题2
class Cat:
     def __init__(self, name):
          self.name = name

class Mouse:
     def __init__(self, name):
          self.name = name

class Test:
     def __init__(self, cat, mouse):
          self.cat = cat
          self.mouse = mouse
     def prt(self):
          print('一只名叫%s的猫抓到了一只名叫%s的老鼠' % (self.cat.name, self.mouse.name))

cat = Cat(input())
mouse = Mouse(input())
t = Test(cat, mouse)
t.prt()



# 操作3
n = int(input())
if n == 0:
     print(0)
else:
     print(2 ** (n-1))
# 递归方法
def f(n):
     if n == 1 or n == 0:
          return n
     return 2 * f(n-1)
     
print(f(n))

