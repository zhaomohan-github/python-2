"""
1c
2b
3b
4d
5b
6d
7b
8c
9a
10b
11c
12b
13b
14b
15d
16a
17b
18b
19a
20b
"""
# 操作1
def f(numbers, target):
    n = len(numbers)
    for i in range(n - 1):
        for j in range(i + 1, n):
            if numbers[i] + numbers[j] == target:
                return True
    return False


# 操作2
class Triangle:
    def __init__(self, b, h):
        self.b = b #底
        self.h = h #高
    def size(self):
        return round(self.b * self.h / 2, 1)

#实例化
t = Triangle(10, 5)
print(t.size())

# 操作3
import turtle as t
t.width(5)

#橡皮
t.fillcolor("tomato")
t.begin_fill()
t.circle(50, 180)
t.left(90)
t.forward(100)
t.end_fill()

#笔杆
t.fillcolor("gold")
t.begin_fill()
t.right(90)
t.forward(250)
t.right(90)
t.forward(100)
t.right(90)
t.forward(250)
t.end_fill()
t.penup()
t.forward(-250)
t.right(150)
t.pendown()

#笔尖
t.forward(100)
t.left(120)
t.forward(100)
t.left(180)
t.forward(70)
t.right(60)
t.fillcolor("black")
t.begin_fill()
t.forward(30)
t.left(120)
t.forward(30)
t.left(120)
t.forward(30)
t.end_fill()

t.hideturtle()
t.done()