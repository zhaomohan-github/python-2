"""
1.B
2.C
3.C
4.B
5.A
6.D
7.C
8.B
9.B
10.C
11.D
12.B
13.B
14.A
15.A
16.A
17.D
18.A
19.A
20.C
"""
# 操作1
lst = list(map(int, input().split()))
num = 0
for n in lst:
     if lst.count(n) > num:
          num = lst.count(n)
          max_num = n
     elif lst.count(n) == num:
          num = lst.count(n)
          max_num = min(n, max_num)
print(max_num)

# 方法2
d = {} # 存储值和出现的次数
for n in lst:
     if n not in d:
          d[n] = 1
     else:
          d[n] += 1
num = 0
for k,v in d.items():
     if num < v:
          num = v
          max_num = min(max_num, k)
print(max_num)

# 操作2
class People:
     def __init__(self, name, age):
          self.name = name
          self.age = age
     def work(self):
          print("working")
     def get_name(self):
          print(self.name)
     def get_age(self):
          print(self.age)

class Student(People):
     def __init__(self, name, age):
          super().__init__(name, age)
     def work(self):
          print("studying")

a = Student('codemao', 10)
a.work()
a.get_name()
a.get_age()

# 操作3
import jieba
t = '月光如流水一般，静静地泻在这一片叶子和花上。薄薄的青雾浮起在荷塘里。叶子和花仿佛在牛乳中洗过一样；又像笼着轻纱的梦。虽然是满月，天上却有一层淡淡的云，所以不能朗照；但我以为这恰是到了好处——酣眠固不可少，小睡也别有风味的。月光是隔了树照过来的，高处丛生的灌木，落下参差的斑驳的黑影，峭楞楞如鬼一般；弯弯的杨柳的稀疏的倩影，却又像是画在荷叶上。塘中的月色并不均匀；但光与影有着和谐的旋律，如梵婀玲上奏着的名曲。'
print(jieba.lcut(t))
