"""
1d
2a
3a
4b
5c
6c
7d
8c
9a
10c
11d
12c
13a
14d
15c
16b
17b
18b
19d
20c
"""

# 操作1 

def f(s):
    return s == s[::-1]

text = input()
print(f(text))

# 操作2 
class Candy:
    def __init__(self, price, number):
        self.price = price #price是单价
        self.number = number #number是数量
    def cal(self):
        return self.price * self.number

c = Candy(1.2, 30)
print(c.cal())

# 操作3 
import turtle as t

#设置画笔
t.width(2)
t.fillcolor("brown1")

#画扇叶的函数
def blade(radius, extent): #radius是扇叶半径，extent是扇叶角度
    t.begin_fill()
    t.forward(radius)
    t.left(90)
    t.circle(radius, extent)
    t.left(90)
    t.forward(radius)
    t.left(180 - extent) #回到函数运行前的画笔角度
    t.end_fill()

#画风扇的函数
def fan(radius, extent): #参数同blade函数
    #后画的图案会覆盖先画的图案，所以要先画扇叶再画风扇中心
    for i in range(4):
        blade(radius, extent)
        t.left((360 - extent * 4) // 2) #每画完一个扇叶，要旋转后才能画下一个扇叶
    t.dot(15) #画风扇中心的点

#调用函数
fan(100, 45)

t.hideturtle()
t.done()